﻿namespace ProductsService
{
  public class ErrorContainer
  {
    public string UserMessage { get; set; }
    public string DevMessage { get; set; }

  }
}
